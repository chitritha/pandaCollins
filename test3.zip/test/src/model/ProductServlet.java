package model;

import java.io.*;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
 * Servlet implementation class ProductServlet
 */
@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher = request.getRequestDispatcher("product.jsp");
		dispatcher.forward( request, response ) ;
		Connection con = null;
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			System.out.println("Error: unable to load driver class!");
		}
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/footwear", "root", "123456");
			Statement statement = con.createStatement();
			HttpSession session = request.getSession();			
			int p = 2;						
			if(session.getAttribute("productId")!=null)
			{
				p = Integer.parseInt((String) session.getAttribute("productId"));												
			} else {
				//p = Integer.parseInt(request.getParameter("Q_no"));
				p = 2;
			}
			String sql = "SELECT productName, image, productType, category, size, color, stock, price FROM products2 where productId = "+(p)+"";						
			ResultSet rs = statement.executeQuery(sql);									
			if(rs.next()) {
				// Retrieve by column name
				String productName = rs.getString("productName");

				String productType = rs.getString("productType");
				String category = rs.getString("category");
				int size = rs.getInt("size");
				String color = rs.getString("color");
				int stock = rs.getInt("stock");
				String price = rs.getString("price");
				int productId = rs.getInt("productId");
				String image = rs.getString("image");

				session.setAttribute("productName",productName );
				session.setAttribute("productType",productType );

				session.setAttribute("category",category );

				session.setAttribute("size",size );
				
				session.setAttribute("productId",productId );
				session.setAttribute("image",image );
				session.setAttribute("stock",stock );

				session.setAttribute("price",price );
				
			}
			if (!rs.next() ) {
				//RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
				//rd.forward(request, response);
				
				//RequestDispatcher rd = request.getRequestDispatcher("Homepage.html");
				//rd.forward(request, response);
				 
			   
			}

			con.close();
		} catch (SQLException e) {
			e.printStackTrace();

		}

		//doGet(request, response);
	}

}
