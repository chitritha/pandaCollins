package com.talentsprint.controller;

import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.talentsprint.model.*;

/**
 * Servlet implementation class DataController
 */
@WebServlet("/DataController")
public class DataController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String x = request.getParameter("userName");
		String y = request.getParameter("password");
		userBean user = new userBean();
		user.setCustomerName(x);
		user.setPassword(y);
		userValidation db = new userValidation();
		boolean b = db.validate(user);
		if(b == true)
			request.getRequestDispatcher("homepage.html").forward(request, response);
		else if(b == false)
			request.getRequestDispatcher("Fail.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String x = request.getParameter("userName");
		String y = request.getParameter("password");
		String e = request.getParameter("email");
		String p = request.getParameter("phone");
		userBean us = new userBean();
		us.setCustomerName(x);
		us.setPassword(y);
		us.setEmail(e);
		us.setCustPhoneNum(p);
		userValidation db = new userValidation();
		int b = db.validateAndSave(us);
		if(b == 1)
			request.getRequestDispatcher("homepage.html").forward(request, response);
		else if(b == 0)
			request.getRequestDispatcher("Fail.jsp").forward(request, response);
		else if(b == -1)
			out.print("Password must be atleast 6 characters");
		else if(b == -2 || b == -3)
			out.print("Invalid credentials!!");
	}

}
