package com.talentsprint.model;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class userDAO
 */
@WebServlet("/userDAO")
public class userDAO extends HttpServlet {
	int noOfRowsAffected;
	public int save(userBean data){
		String userName = data.getUserName();
		String password = data.getPassword();
		String email = data.getEmail();
		String phone = data.getPhone();
		String sql = "insert into users(user_Name, password, email, phone_no) values(?,?,?,?)";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/footwear", "root","123456");
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userName);	
			pstmt.setString(2, password);
			pstmt.setString(3, email);	
			pstmt.setString(4, phone);
			noOfRowsAffected = pstmt.executeUpdate();
			con.close();
		} catch(SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(noOfRowsAffected > 0)
			return 1;
		return 0;
	}
	public boolean search(userBean data){
		 	String userName = data.getUserName();
	        String password = data.getPassword();
	      //  System.out.println(userName);
	       // System.out.println(password);
	        //String userNameDB = "";
	         String passwordDB = "";
	        Connection con = null;
	         Statement statement = null;
	         ResultSet resultSet = null;
	        try {
	            Class.forName("com.mysql.jdbc.Driver");
	            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/footwear", "root","123456");
	            statement  = con.createStatement();
	            resultSet = statement.executeQuery("select password from users where user_Name= '" + userName +"'");
	            while(resultSet.next()){
	               // userNameDB = resultSet.getString("user_Name"); //fetch the values present in database
	                passwordDB = resultSet.getString("password");            
	                if(password.equals(passwordDB)) {
	                	return true;
	                } else {
	                	return false;
	                }
	            }
	        } catch(SQLException e) {
	            e.printStackTrace();
	        } catch (ClassNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        return false;
	}
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userDAO() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
